package com.example.filipenotebook.calendar;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.util.ArrayList;


public class ManualSelectedEvent extends ActionBarActivity {
    private ArrayList days;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual_selected_event);
        TextView tv1 = (TextView)findViewById(R.id.selectedEventManual);
        String eventName = getIntent().getStringExtra("eventName");
        int hourStart = getIntent().getIntExtra("hourStart",0);
        int minuteStart = getIntent().getIntExtra("minuteStart",0);
        int hourEnd = getIntent().getIntExtra("hourEnd",0);
        int minuteEnd = getIntent().getIntExtra("minuteEnd",0);
        boolean repeat = getIntent().getBooleanExtra("repeat",false);

        tv1.setText("Event name: " + eventName + " starting at: " + pad(hourStart) +":" + pad(minuteStart)+ " and ending at: "+ pad(hourEnd) +":" +pad(minuteEnd) );
        if (repeat == true)
            tv1.append(" and will repeat");
        days();
    }
    private static String pad(int c) {
        if (c >= 10)
            return String.valueOf(c);
        else
            return "0" + String.valueOf(c);
    }
    public void days(){
        boolean sunday = getIntent().getBooleanExtra("sunday",false);
        boolean monday = getIntent().getBooleanExtra("monday",false);
        boolean tuesday = getIntent().getBooleanExtra("tuesday",false);
        boolean wednesday = getIntent().getBooleanExtra("wednesday",false);
        boolean thursday = getIntent().getBooleanExtra("thursday",false);
        boolean friday = getIntent().getBooleanExtra("friday",false);
        boolean saturday = getIntent().getBooleanExtra("saturday",false);

        TextView tv2 = (TextView)findViewById(R.id.daysManual);
        if (sunday == true)
            tv2.append("Sunday ");
        if (monday == true)
            tv2.append("Monday ");
        if (tuesday == true)
            tv2.append("Tuesday ");
        if (wednesday == true)
            tv2.append("Wednesday ");
        if (thursday == true)
            tv2.append("Thursday ");
        if (friday == true)
            tv2.append("Friday ");
        if (saturday == true)
            tv2.append("Saturday ");

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_manual_selected_event, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
